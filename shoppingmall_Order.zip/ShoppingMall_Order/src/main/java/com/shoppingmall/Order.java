package com.shoppingmall;

import java.sql.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer orderId;
	private int customerId;
	private int storeId;
	private Date orderDate;
	private double totalPrice;
	private String status;
	
	public Order() {
		super();
		
	}

	public Order(Integer orderId, int customerId, int storeId, Date orderDate, double totalPrice, String status) {
		super();
		//this.orderId = orderId;
		this.customerId = customerId;
		this.storeId = storeId;
		this.orderDate = orderDate;
		this.totalPrice = totalPrice;
		this.status = status;
	}
	
	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", customerId=" + customerId + ", storeId=" + storeId + ", orderDate="
				+ orderDate + ", totalPrice=" + totalPrice + ", status=" + status + ", getOrderId()=" + getOrderId()
				+ ", getCustomerId()=" + getCustomerId() + ", getStoreId()=" + getStoreId() + ", getOrderDate()="
				+ getOrderDate() + ", getTotalPrice()=" + getTotalPrice() + ", getStatus()=" + getStatus()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

}
