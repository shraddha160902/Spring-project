package com.shoppingmall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingMallOrderApplication {

	public static void main(String[] args) 
	{
		SpringApplication.run(ShoppingMallOrderApplication.class, args);
	}

}
